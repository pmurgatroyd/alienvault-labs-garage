import cProfile

def ProfileRegex(regexp):
    pass
    #profile = cProfile.run(regexp, filename, sort)
    

def ProfileRegexAgainstLog(regexp):
    pass

    

